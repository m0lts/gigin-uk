# Handoff: The rest of the artist experience

## Overview
These are the screens and emails an artist meets after the guest apply flow (`design_handoff_guest_apply/`), the multi-set changes (`design_handoff_multiset_apply/`) and keep-profile (`design_handoff_keep_profile/`):
1. The **manage application** page (pending, accepted, declined, withdrawn, set changed, link stopped working), with the Keep my profile card.
2. **Gig page edge states**: applications closed, night full, night cancelled, gig not found, and the "already has an account" prompt on the apply form.
3. **Media share** gallery with Download all, a viewer, and the empty, error and revoked states.
4. **Keep-profile account steps** (create a password, profile live) and **artist log in** (password, Google, forgot password, sign-in link, reset).
5. **Eight emails**, as HTML and plain text, 600px, dark-mode safe.
6. The privacy note on the guest form, plus empty and error states.

The domain is **giginmusic.com**. Emails come from **Gigin &lt;noreply@giginmusic.com&gt;**. There are **no payments, fees, ticketing or chat** anywhere.

## About the design files
- `artist-experience.html`: the clickable canvas. Frames 1a–1m are manage, 2a–2i gig edges, 3a–3f media, 4a–4o account and log in, 5a–5h emails (light), 6a–6h emails (dark), 7a–7h emails (plain text). Mobile frames are 375px, desktop 1280px. It's a **design reference**: don't copy its markup. Recreate it in React + plain CSS with the existing `ga-*` / `kp-*` classes and `--gn-*` tokens.
- `emails/`: **send-ready templates**, one `.html` and one `.txt` per email, plus `artist-emails.js`, the single source both are rendered from. Port these into `emailShell` / `emailGuest` in `gigin-api` (keep the table markup and inline styles as they are), replacing the sample values with the variables listed under Emails.
- Sample content (Jez, Jesus College Bar, The Fen Street Trio, Sam Okoro, Fri 13 Nov, the set times and the file names) is illustrative.

## Fidelity
**High-fidelity.** Colours, type, spacing, radii, copy and states are final. All copy is in `COPY.md`.

## Tokens
These are the same as guest apply and keep-profile: Geist / Geist Mono / Visby CF (wordmark only), `--gn-ink` #0F1115, `--gn-ink-2` #4B5160, `--gn-muted` #6B7280, `--gn-line` #E5E7EB, `--gn-line-soft` #F0F1F3, `--gn-console-bg` #F6F7F9, `--gn-orange` #FF6C4B, `--gn-new-bg` #FFEDE7, `--gn-new-text` #B5462C, `--gn-error` #E5484D, `--gn-error-text` #C52A2F, `--gn-danger` oklch(0.52 0.16 25), `--gn-warn-soft-bg` #FFF7F4 / `--gn-warn-soft-border` #FFD2C6, plus the green and amber status colours.
- Error and alert boxes: #FFF7F4 bg, #FFD2C6 border, #8A2E1A text, radius 10–12. Title 14.5/600, body 14/1.5.
- Amber notice (set changed): bg `oklch(0.97 0.035 80)`, border `oklch(0.88 0.07 80)`, title `oklch(0.4 0.1 60)`.
- **Orange is only used for Apply to play, Send application and the email buttons.** Every other primary is #111317.
- Inputs are 52px with 16px text. Primary buttons are 54px (52 on desktop). Tap targets are 44px+. Focus: 2px #FF6C4B outline, offset 2.

## Layout
- **Mobile (< 768px):** a 56px header (`gigin.` and a right-hand label), 18px side padding, content max 640px. Gig and apply pages keep the sticky bottom action bar. Sheets are bottom sheets (radius 18 18 0 0).
- **Desktop (768px and up):** manage, gig and apply pages use a 640px main column + a 340px sticky **gig aside** (photo, date, name, venue, sets, address; on gig pages the disabled Apply button with its reason). Media uses a 1040px single column. Account pages are a centred 440px white card (radius 18, 1px border) on #F6F7F9. Sheets become centred 480px dialogs.

---

## 1. Manage application (`ManageGuestApplication.jsx`)
Header right: "Private link for {first name}". Then the mono date line `FRIDAY 13 NOVEMBER 2026 · JESUS COLLEGE BAR`, the heading (28px mobile / 36px desktop) and the status pill.

| State | Heading | Pill | Body |
|---|---|---|---|
| Pending (1a) | Your application | amber "Sent · Jez hasn't decided yet" | Review list (Act and contact · Set preference · Photo and links · Tech rider · Note to Jez), each with **Edit**. Line: "You can make changes until Jez confirms the line-up. Jez is told about each change." **Keep my profile** card. **Withdraw my application** (red text link). |
| Accepted (1e) | You're playing Set 1 | green "Accepted · Set 1, 20:00–21:00" | The booking card (existing `ga-booking`): `YOUR SET`, "Set 1" 30px, `20:00–21:00 · 60 minutes` mono 16, rows Doors / Where / Booked by, **Add to calendar** (.ics). Keep card. "Plans changed?" + **I can't play any more**. No review list. |
| Accepted, no set | You're in | green "Accepted · set time to be confirmed" | As today (unchanged). |
| Set changed (1h) | You're now playing Set 2 | green "Accepted · Set 2, 21:15–22:15" | Amber notice "Your set has changed" above the booking card. The card's label is `YOUR NEW SET`, with the old set struck through under the time (`Was Set 1 · 20:00–21:00`, mono 13 #6B7280). Show the notice until the artist has seen the page once after the change (`setChangeSeenAt`). |
| Declined (1i) | Your application | grey "Not this time" | The existing kind line, plus **See upcoming gigs at the bar**. No review, no edit, no keep card. |
| Withdrawn (1j, 1k) | Your application | grey "Withdrawn" | The existing copy (before / after accept) + **Back to the gig**. |
| Link stopped working (1l, 1m) | This link has stopped working | — | See below. |

- **Keep my profile card:** shown on pending and accepted when `FEATURES.keepProfile`, there's no `artistProfileId`, and `keepProfileOffer` isn't `confirmed`. It's the same card as `KeepOffer.jsx` (spec in the keep-profile README): `FOR NEXT TIME · FREE`, title, body, mini preview, **Keep my profile** (dark), "We'll email you a link to confirm. You'll create a password when you confirm.", **Not now**. When sent, show "Check your email" + Resend / Wrong email?. When dismissed, show the dashed line with **Undo**. If dismissed earlier (`keepProfileOffer: 'dismissed'`), start collapsed. If a profile exists, show the existing "Your Gigin profile" card instead.
- **Edit the note (1a → 1c):** inline textarea (500 max, mono counter), **Save** (dark) / Cancel. Saving shows "Saving…". On failure, show the error box "**Your note didn't save.** Check your connection and try again. What you typed is still here." and keep the editor open. On success, the toast "Saved. Jez can see your changes." Use the same error box for every edited step.
- **Withdraw sheet** and **I can't play sheet:** unchanged copy (see `COPY.md`).
- **Link stopped working (1l):** any invalid, rotated or expired token (`getGuestApplication` 404/410). Heading "This link has stopped working". Body "Private links stop working when we send you a newer one, and 7 days after the gig. Enter the email you applied with and we'll send a fresh link." Field "Email you applied with" + **Email me a fresh link** → `POST /guest-applications/magic-link { gigId, email }` (existing). Then (1m) "Check your inbox. If {email} applied to this gig, we've sent a fresh link. It can take a minute to arrive." **Same answer whether or not it matched.** Never show any application details on this page.

## 2. Gig page edge states (`GuestGigPage.jsx`)
The banner sits above the hero photo. Each set row's tag shows the reason. The primary button (mobile bottom bar, desktop aside) is disabled with the reason as its label.

| State | Trigger | Banner | Set tag | Button |
|---|---|---|---|---|
| Applications closed (2a) | every slot `applicationsOpen === false` | grey, "Applications have closed" (existing copy) + **Follow {venue}** | Closed | Applications closed |
| Night full (2b) | `allTaken` | grey, "All sets are filled" (existing copy) + **Follow {venue}** | Taken | All sets filled |
| Cancelled (2c, 2d) | **new:** any slot `status === 'cancelled'` (all slots cancelled) | #FFF7F4 / #FFD2C6, title #8A2E1A "This gig has been cancelled" + **See upcoming gigs at the bar** | Cancelled | Gig cancelled |
| Not found (2e) | unknown gigId or deleted gig | Full page: "We can't find this gig" + "Already applied? … **Get a fresh link**" (→ landing page `#artists`) + **Go to giginmusic.com** | — | — |

- On a cancelled gig, the title is struck through in #6B7280 and the photo is at 50% opacity. Cancelled takes priority over closed/full. "This gig has already happened" (past) stays as it is.
- The manage page for a cancelled gig shows a grey pill "Gig cancelled" and the same banner copy. Edit and withdraw are hidden.

### Already has an account (2f, 2g, 2h, `GuestWhoStep.jsx`)
When the email field loses focus and `checkGuestEmailAccount` returns `hasAccount`, show a card under the contact rows (#F6F7F9, 1px border, radius 14): `YOU'RE ALREADY ON GIGIN` · "{email} has a Gigin account" · "Log in and we'll fill this in from your profile and keep the application with your account. You can also carry on as a guest." · **Log in** (dark, opens the log in screen with the email filled in; after log in, return to the wizard with the pre-filled review page from keep-profile 6a) · **Carry on as a guest** (collapses the card to the line "Sending as a guest. Next time you log in, we'll add this application to your account.").
- **This never blocks Continue.** Remove the old "This email already has a Gigin account. Log in to apply." error for good.

### Privacy note (2i, all of step 1)
An #FAFBFC box with a 1px #F0F1F3 border and radius 12 sits above the action bar: "Your email and phone number only go to Jez and the bookers at {venue}. We only email you about this application, and never show your details publicly. **Privacy policy**". It's 13.5px #4B5160. Use `{bookerFirstName}` and `{venueName}`.

## 3. Media share (`GigMediaSharePage.jsx`, `/share/gig-media/:token`)
Restyle the existing page. The API already has `GET /share/:token`, `/file/:mediaId` and `/zip`.
- Header right: "Shared by {venue}". Mono line `{GIG NAME} · {FRI 13 NOV 2026}`, H1 "Photos and videos", then "From {venue} · {n} photos, {m} videos · {total size}".
- **Download all ({size})**: dark 52px, max 360px. While starting: "Preparing your zip…" (disabled), then the green note "Your download has started: {slug}.zip ({size}). Check your downloads folder." Next to it: "On a phone, a big zip can be slow. You can also save files one at a time."
- **Grid:** `repeat(auto-fill, minmax(150px, 1fr))`, gap 8, square tiles, radius 10. Videos get a "▶ 0:42" badge. Tiles are buttons (`aria-label` "Photo 3 of 12, IMG_2040.jpg").
- **Viewer (3c):** full screen #0B0C0F. A "3 of 12" counter, ✕ (Esc), prev / next (44×64, and the arrow keys and swipe), the file name + size, and **Download** (white). Videos play inline with `controls`, `preload="metadata"`.
- Footnote: "This link is private. {venue} shared it with the acts who played. Ask before posting photos of other acts."
- **Zip failed (3d):** the error box "The download didn't finish" + **Try again**. The zip is streamed, so detect the failure by fetching it as a blob with progress on desktop. On mobile, use a plain link and show this box only if the request fails.
- **Empty (3e):** "No photos or videos yet" / "{venue} hasn't added any files to this gig yet. Keep this link and check back after the night."
- **Revoked or unknown token (3f):** "This link is no longer available" / "The venue may have made a new link or turned sharing off. Ask them to send you a new one." + **Go to giginmusic.com**. Today's API returns 404 for both cases, and there's no time-based expiry. Keep it that way.
- **API additions:** `GET /share/:token` should also return `gigDate`, `contentType`, `size`, `width`/`height` and `durationSec` per file, plus a `thumbUrl` (resized, 600px, signed for 1 hour) for the grid. Add `?inline=1` on `/file/:mediaId` for the viewer (`Content-Disposition: inline`).

## 4. Keep-profile account steps and log in
### Create a password (4a–4d, `ConfirmProfilePage`, state `password`)
The confirm link lands here. Eyebrow `✓ EMAIL CONFIRMED` (green mono), H1 "Create a password", "This puts your profile live and creates your Gigin login. Next time, log in at giginmusic.com with this email and password."
- **Email:** read-only box (#F6F7F9).
- **Password:** 52px with **Show / Hide** inside on the right (44px target, `aria-pressed`), `autocomplete="new-password"`.
- **Strength hint** (4 bars of 4px, then a line):
  - Empty: "Use 8 or more characters. A few words together is easy to remember and hard to guess."
  - Under 8: red 1 bar, "**Too short.** Add {n} more characters."
  - A common password (check a small list client-side; Firebase enforces too): red 1 bar, "**Too common.** This is one of the most guessed passwords. Try a few words together."
  - 8–11 characters with fewer than 3 character kinds: amber 2 bars, "**Okay.** Longer is stronger. Add another word or a few numbers."
  - 12+ characters, or 3+ kinds: green 4 bars, "**Strong.** Good to go."
- **Put my profile live** (dark). On submit with fewer than 8 characters: "Use at least 8 characters." Then `claimProfileAccount(token, { password })` and `signInWithEmailAndPassword` (existing).
- "or", then **Continue with Google**, then "Use the Google account for {email}." Use `signInWithPopup(googleProvider)`, then claim with the ID token. **If the Google email isn't the profile email (4d):** "**That Google account is {googleEmail}.** Your profile is for {email}. Choose that Google account, or create a password instead." Don't link the profile.
- Existing account, expired and used link states stay as in the keep-profile handoff.

### Your profile is live (4e)
This is the existing `ProfileLive`, with the signed-in line merged into the body: "Anyone with the link can see it. Your email and phone number stay private. You're signed in, so next time log in at giginmusic.com with your email and password." (With Google: "…log in with Google.") It has `YOUR LINK` + **Copy** (→ "Copied ✓") + **Share to WhatsApp, Instagram…**, then **Go to my Gigin home** (`/home`). Keep the Find venues card behind `venueFinder`.

### Log in (4g–4i)
Build this inside the existing auth modal (`setAuthType('login')`): full screen on mobile, a 440px dialog on desktop. It's the same for venues and artists.
- H1 "Log in", "For venues, and artists who've kept a Gigin profile."
- Email, then Password with Show / Hide (`current-password`), with **Forgot password?** to the right of the Password label.
- **Log in** (dark), "or", **Continue with Google**.
- The quiet fallback **Email me a sign-in link instead** (a text button, 14.5px #4B5160 underlined), using Firebase `sendSignInLinkToEmail` (`handleCodeInApp: true`, url `/auth/email-link`). Store the email in localStorage, as Firebase expects. If it's opened on another device, ask for the email again. With no email entered: "Enter your email first, and we'll send the link there."
- Footnote: "Applied to a gig as a guest? You don't need to log in. Use the private link in your email, or **get a fresh link**."
- **Errors:** empty email "Enter your email address." · bad format "Enter an email address like name@example.com." · empty password "Enter your password." · `auth/invalid-credential` / `wrong-password` / `user-not-found` → one banner, "**That email and password don't match.** Try again, or reset your password." · `auth/too-many-requests` → "**Too many attempts.** Wait a few minutes, or reset your password." · network → "**No connection.** Check your signal and try again."
- After log in: venues go to `/venues/dashboard`, artists to `/home` (or back to the page that opened the modal).

### Forgot and reset (4j–4o)
- **Forgot (4j):** "Reset your password" / "Enter the email you log in with and we'll send a link to choose a new password." / **Email me a reset link** / Back to log in.
- **Sent (4k) and sign-in link sent (4l):** "Check your email" + the body from `COPY.md`, "Nothing there? Check your spam folder. **Send it again**" (disabled for 30s: "Send again in 30s"), **Use a different email**, **Back to log in**. Always the same answer, so there's no account enumeration.
- **Choose a new password (4m):** route `/auth/reset?oobCode=` (set this as the Firebase custom action URL). "For {email}." (from `verifyPasswordResetCode`), the same password field + strength hint, **Save and log in** → `confirmPasswordReset`, then sign in.
- **Changed (4n):** "Password changed" / "You're logged in as {email}. Use your new password next time." / **Go to my Gigin home**.
- **Expired or used (4o):** "This reset link has expired" / "Reset links work once, for 1 hour. Send yourself a new one." with the email pre-filled, and **Email me a new link**.

## 5. Emails
Files: `emails/{kind}.html` + `emails/{kind}.txt`. They're built with nested tables, inline styles, a 600px max width and a 100%-width fallback, a bulletproof button, a hidden preheader, and no images (the wordmark is live text, so nothing breaks with images off).
- **Dark mode:** `<meta name="color-scheme" content="light dark">`, `@media (prefers-color-scheme: dark)` rules on classes (`.bg .card .ink .muted .eyebrow .box .boxg .labg .rule .link .btnd`), and the same rules under `[data-ogsc]` for Outlook.com. Gmail apps force their own inversion; the palette has no light-on-light pairs, so it stays readable. The orange button keeps white text in both themes.
- **Mobile:** under 620px, card padding drops to 24px 18px and buttons go full width.
- **Plain text:** the `text/plain` part of every send. It has the same content, URLs on their own lines, and no tracking.

| Kind | When | Subject | Button |
|---|---|---|---|
| `received` | Guest application created (existing, restyle) | You've applied to play {gig} at {venue} | Change or withdraw your application (orange) |
| `accepted` | Accepted with a set (multiset email 3) | You're playing {Set 1} at {venue} on {Fri 13 Nov} | View your booking. Attach `gigin-set.ics` |
| `declined` | At `declineEmailSendAt` | Update on your application for {gig} | See upcoming gigs at the bar (dark), plus the keep-profile reminder block (rules in the keep-profile README) |
| `setChanged` | An assigned act moved to another set | Your set has changed: you're now playing {Set 2} on {Fri 13 Nov} | View your booking. Attach the updated .ics with the same `UID` and `SEQUENCE + 1` |
| `mediaReady` | Venue taps "Email confirmed acts" (`/share/email`) | Your photos and videos from {gig} | View and download |
| `keepConfirm` | Keep my profile (keep-profile 3a, now with a password step) | Confirm your Gigin profile for {act} | Confirm my profile (orange) |
| `passwordReset` | Firebase reset (send our own via the Admin SDK `generatePasswordResetLink`, so it matches) | Reset your Gigin password | Choose a new password (dark) |
| `reminder` | **New:** 10:00 the day before the gig, to accepted acts with a set (Cloud Scheduler, idempotent via `reminderSentAt`) | Tomorrow: you're playing {Set 1} at {venue} | View your booking |

Variables: `{firstName} {actName} {gigName} {venueName} {bookerFirstName} {bookerRole} {dayLong} {dayShort} {setName} {setRange} {setMinutes} {doors} {address} {arrivalNotes} {manageUrl} {venueUrl} {mediaUrl} {fileSummary} {totalSize} {confirmUrl} {keepChoicesUrl} {resetUrl} {email} {barProvides} {bringOwn}`. Hide rows whose value is empty (for example "You're bringing").

## Data and server
- `guestApplicants`: add `setChangedFrom?: { slotGigId, label, range }`, `setChangeSeenAt?`, `reminderSentAt?`.
- Gig slots: read `status === 'cancelled'` (already written by the cancel handlers in `gigs.js`). On cancel, close any open applications (no email change in this handoff).
- `GET /share/:token`: add the metadata and `thumbUrl` (section 3). `/file/:mediaId?inline=1`.
- New scheduled job: `sendSetReminders` (daily 10:00 Europe/London).
- Auth: Firebase email-link sign-in enabled, with the action URL `https://giginmusic.com/auth/action` routing `resetPassword` → `/auth/reset` and `signIn` → `/auth/email-link`.

## Feature flags
No new flags. The Keep my profile card follows `keepProfile`. The Find venues card on the live screen follows `venueFinder`. Everything else is always on.

## Don't change
- Don't modify Sidebar.jsx or the sidebar styles in dashboard.styles.css. They're already final.
- Venue-side wording stays "Offer", not "Invite".

## Files
- `artist-experience.html`: the clickable canvas (all frames, emails light / dark / text, notes).
- `emails/`: 8 × `.html` + `.txt`, and `artist-emails.js` (the source).
- `COPY.md`: every string, by screen and state.
- `CURSOR_PROMPT.md`: the prompt to paste into Cursor.
