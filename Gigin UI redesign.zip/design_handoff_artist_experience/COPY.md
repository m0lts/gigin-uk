# Artist experience copy (final)

Use these strings verbatim. `{x}` is a value. Sample values: Jez (booker), Jesus College Bar (venue), Friday Night Live (gig), The Fen Street Trio (act), Sam (first name).

## 1. Manage application
Header right: Private link for {first}
Date line: {FRIDAY 13 NOVEMBER 2026} · {JESUS COLLEGE BAR}

### Pending
- Heading: Your application
- Pill: Sent · {booker} hasn't decided yet
- Rows: Act and contact · Set preference · Photo and links · Tech rider · Note to {booker} — each with Edit
- Under the list: You can make changes until {booker} confirms the line-up. {booker} is told about each change.
- Link: Withdraw my application
- Saving: Saving…
- Saved toast: Saved. {booker} can see your changes.
- Save failed: **Your note didn't save.** Check your connection and try again. What you typed is still here.
  (Other steps: "Your changes didn't save." with the same second sentence.)

### Accepted
- Heading: You're playing {Set 1}
- Pill: Accepted · {Set 1}, {20:00–21:00}
- Card label: YOUR SET · {Set 1} · {20:00–21:00} · {60} minutes
- Rows: Doors · Where · Booked by
- Button: Add to calendar
- Toast: Saved gigin-set.ics. Open it to add the set to your calendar.
- Plans changed? / Let {booker} know as soon as you can, so the set can go to someone else. / I can't play any more

### Set changed
- Heading: You're now playing {Set 2}
- Pill: Accepted · {Set 2}, {21:15–22:15}
- Notice title: Your set has changed
- Notice body: {booker} moved {act} from {Set 1} ({20:00}) to {Set 2} ({21:15}). Everything else stays the same. We've emailed you an updated calendar file.
- Card label: YOUR NEW SET · struck line: Was {Set 1} · {20:00–21:00}

### Declined
- Pill: Not this time
- Body: {booker} has picked the line-up for {Friday 13 November} and couldn't fit {act} in this time. Thanks for applying. The bar has your details for future nights.
- Link: See upcoming gigs at the bar

### Withdrawn
- Pill: Withdrawn
- Before accept: {booker} has been told you can't make this gig. You can apply again while it's still open.
- After accept: We've told {booker} {act} can't play on {Fri 13 Nov}, so the set can go to someone else. Thanks for letting the bar know.
- Link: Back to the gig

### Sheets
- Withdraw your application? / {booker} will be told you can't make {Fri 13 Nov}. You can apply again while the gig is still open. / Yes, withdraw / Keep my application
- Tell {booker} you can't play? / {booker} will be told {act} can't make {Fri 13 Nov}, and the set will be offered to someone else. This can't be undone. / Yes, I can't play / Keep my booking

### Keep my profile card
- FOR NEXT TIME · FREE
- Keep this as your Gigin profile
- Your bio, photos, links, band info and tech rider in one place, with a link you can send to any venue when you're looking for gigs.
- Keep my profile
- We'll email you a link to confirm. You'll create a password when you confirm.
- Not now
- Sent: Check your email / We've sent a link to {email}. Tap it to confirm and create a password. Nothing is public until you do. / Resend the link · Wrong email?
- Dismissed: No problem. If you change your mind, there's a link in the emails we send about this application. / Undo

### Link stopped working
- Eyebrow: YOUR APPLICATION
- This link has stopped working
- Private links stop working when we send you a newer one, and 7 days after the gig. Enter the email you applied with and we'll send a fresh link.
- Label: Email you applied with
- Button: Email me a fresh link
- Errors: Enter the email you applied with. / Enter an email address like name@example.com.
- Sent: Check your inbox / If {email} applied to this gig, we've sent a fresh link. It can take a minute to arrive.

## 2. Gig page edge states
- Closed: **Applications have closed** {booker} has stopped taking applications for {13 November}. Follow the bar on Gigin to hear about future nights. · Follow {venue} · tag Closed · button Applications closed
- Full: **All sets are filled** {booker} has booked every set for {Fri 13 Nov}, so this gig isn't taking applications any more. Follow the bar on Gigin to hear about future nights. · Follow {venue} · tag Taken · button All sets filled
- Cancelled: **This gig has been cancelled** {venue} has cancelled {gig} on {Friday 13 November}. If you'd applied, your application is closed and there's nothing you need to do. · See upcoming gigs at the bar · tag Cancelled · button Gig cancelled · manage pill Gig cancelled
- Not found: GIGINMUSIC.COM/GIG/… · We can't find this gig · The link might be missing a few characters, or the venue has taken the gig down. Check the link with whoever sent it to you. · Already applied? Your private link is in the email we sent you. Get a fresh link · Go to giginmusic.com

### Already has an account (apply step 1)
- YOU'RE ALREADY ON GIGIN
- {email} has a Gigin account
- Log in and we'll fill this in from your profile and keep the application with your account. You can also carry on as a guest.
- Log in · Carry on as a guest
- After guest: Sending as a guest. Next time you log in, we'll add this application to your account.

### Privacy note (apply step 1)
Your email and phone number only go to {booker} and the bookers at {venue}. We only email you about this application, and never show your details publicly. Privacy policy

## 3. Media share
- Header right: Shared by {venue}
- {GIG NAME} · {FRI 13 NOV 2026}
- Photos and videos
- From {venue} · {9} photos, {3} videos · {184 MB}
- Button: Download all ({184 MB}) / Preparing your zip…
- Beside it: On a phone, a big zip can be slow. You can also save files one at a time.
- Started: Your download has started: {friday-night-live}.zip ({184 MB}). Check your downloads folder.
- Failed: **The download didn't finish** The connection dropped while we were building the zip. The files are fine. Try again, or save them one at a time. · Try again
- Tile label: Photo {3} of {12}, {IMG_2040.jpg} / Video …
- Viewer: {3} of {12} · Download · Close · Previous · Next · toast Downloading {file}
- Footnote: This link is private. {venue} shared it with the acts who played. Ask before posting photos of other acts.
- Empty: No photos or videos yet / {venue} hasn't added any files to this gig yet. Keep this link and check back after the night.
- Unavailable: PHOTOS AND VIDEOS / This link is no longer available / The venue may have made a new link or turned sharing off. Ask them to send you a new one. / Go to giginmusic.com

## 4. Account and log in
### Create a password
- ✓ EMAIL CONFIRMED
- Create a password
- This puts your profile live and creates your Gigin login. Next time, log in at giginmusic.com with this email and password.
- Labels: Email · Password · Show / Hide
- Strength: (empty) Use 8 or more characters. A few words together is easy to remember and hard to guess. / **Too short.** Add {n} more character(s). / **Too common.** This is one of the most guessed passwords. Try a few words together. / **Okay.** Longer is stronger. Add another word or a few numbers. / **Strong.** Good to go.
- Errors: Use at least 8 characters. / Choose a less common password.
- Button: Put my profile live / Saving…
- or · Continue with Google · Use the Google account for {email}.
- Google mismatch: **That Google account is {googleEmail}.** Your profile is for {email}. Choose that Google account, or create a password instead.

### Your profile is live
- Your profile is live
- Anyone with the link can see it. Your email and phone number stay private. You're signed in, so next time log in at giginmusic.com with your email and password. (Google: …next time log in with Google.)
- YOUR LINK · Copy / Copied ✓ · Share to WhatsApp, Instagram… · Go to my Gigin home

### Log in
- Log in
- For venues, and artists who've kept a Gigin profile.
- Email · Password · Show / Hide · Forgot password?
- Log in / Logging in…
- or · Continue with Google
- Email me a sign-in link instead
- Applied to a gig as a guest? You don't need to log in. Use the private link in your email, or get a fresh link.
- Errors: Enter your email address. / Enter an email address like name@example.com. / Enter your password. / Enter your email first, and we'll send the link there.
- Banners: **That email and password don't match.** Try again, or reset your password. / **Too many attempts.** Wait a few minutes, or reset your password. / **No connection.** Check your signal and try again.

### Forgot, sent, reset
- Reset your password / Enter the email you log in with and we'll send a link to choose a new password. / Email me a reset link / Back to log in
- Check your email / If {email} has a Gigin account, we've sent a link to choose a new password. It works once, for 1 hour.
- Check your email / We've sent a sign-in link to {email}. Open it on this device to log in. It works once, for 1 hour.
- Nothing there? Check your spam folder. Send it again / Send again in {30}s · toast Sent again.
- Use a different email · Back to log in
- Choose a new password / For {email}. / New password / Save and log in
- Password changed / You're logged in as {email}. Use your new password next time. / Go to my Gigin home
- This reset link has expired / Reset links work once, for 1 hour. Send yourself a new one. / Email me a new link

## 5. Emails
The full text of each email is in `emails/{kind}.txt`. Subjects and preheaders:
- received: You've applied to play {gig} at {venue} · {booker} has your application for {Friday 13 November}.
- accepted: You're playing {Set 1} at {venue} on {Fri 13 Nov} · {Set 1}, {20:00–21:00}. Doors {19:30}.
- declined: Update on your application for {gig} · {booker} has picked the line-up for {Friday 13 November}.
- setChanged: Your set has changed: you're now playing {Set 2} on {Fri 13 Nov} · {Set 2}, {21:15–22:15}. Everything else stays the same.
- mediaReady: Your photos and videos from {gig} · {venue} has shared {12} files from {Friday 13 November}.
- keepConfirm: Confirm your Gigin profile for {act} · Tap the link to confirm your email and create a password. Nothing is public until you do.
- passwordReset: Reset your Gigin password · The link works once, for 1 hour.
- reminder: Tomorrow: you're playing {Set 1} at {venue} · {Set 1}, {20:00–21:00}. Doors {19:30}.

## 6. Shared states
- Loading: the header plus three grey 14px bars (#F0F1F3). No text.
- Offline toast: No connection. Try again when you're back online.
