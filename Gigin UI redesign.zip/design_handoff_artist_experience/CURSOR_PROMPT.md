Implement the rest of the artist experience described in `design_handoff_artist_experience/README.md`, with every string from `design_handoff_artist_experience/COPY.md`. It builds on `design_handoff_guest_apply/`, `design_handoff_multiset_apply/` and `design_handoff_keep_profile/`.

- Visual reference: `design_handoff_artist_experience/artist-experience.html`. 1a–1m are manage, 2a–2i gig edge states, 3a–3f media, 4a–4o account and log in, 5–7 the emails (light, dark, plain text). Match it exactly. It's a design reference, so don't copy its markup. Build it in React + plain CSS with the existing `ga-*` / `kp-*` classes and `--gn-*` tokens.
- The email templates in `design_handoff_artist_experience/emails/` are send-ready. Port their table markup and inline styles into `gigin-api` (`emailShell` / `emailGuest`) as they are, swap the sample values for variables, and send every email with both the HTML and the `.txt` part.
- The domain is **giginmusic.com** everywhere. Emails come from **Gigin <noreply@giginmusic.com>**.
- No payments, fees, ticketing or chat. Venue-side wording stays "Offer", not "Invite". Don't modify Sidebar.jsx or the sidebar styles in dashboard.styles.css. They're already final.
- Reuse what exists: `ManageGuestApplication.jsx`, `GuestGigPage.jsx`, `GuestWhoStep.jsx` (`checkGuestEmailAccount`), `KeepOffer.jsx`, `ProfilePages.jsx` (`ConfirmProfilePage`, `ProfileLive`, `claimProfileAccount`), `GigMediaSharePage.jsx` and `routes/gigMedia.js`, `useAuth.js` (Google popup, reset), the auth modal, `/guest-applications/magic-link`, and the `.ics` helper in `guestFormat.js`.
- Never reveal whether an email has an account or an application: the fresh-link, reset and sign-in-link screens always give the same answer.

Work in this order:
1. Server: `status === 'cancelled'` handling for gigs and applications, `setChangedFrom` / `setChangeSeenAt` / `reminderSentAt`, the media share metadata + `thumbUrl` + `?inline=1`, the `sendSetReminders` scheduled job, Firebase email-link sign-in and the custom action URL, and an Admin-SDK password reset sent with our template.
2. Emails: port all 8 templates (HTML + text, dark-mode classes, `[data-ogsc]` rules), the .ics attachments (same UID, bumped SEQUENCE on set change), and wire each one to its trigger.
3. Manage page: every state in section 1, the keep card states, inline note editing with the save error, the set-changed notice, the cancelled-gig state and the "link stopped working" page with the fresh-link form.
4. Gig page: closed, full, cancelled and not-found states, the non-blocking "already has an account" card, and the privacy note on step 1.
5. Media share: the gallery, viewer, Download all with its started / failed states, and the empty and unavailable states.
6. Account: Create a password (strength hint, show / hide, Google with the email-match check), the merged live screen, and the log in modal (password, Google, forgot password, sign-in link, all error banners), plus the reset, changed and expired pages.
7. Check every frame at 375px and 1280px against the prototype, and test the emails in Apple Mail and Gmail in light and dark mode.

Build all steps in one go without pausing for review. When you're done, give me a short summary of what changed, any assumptions you made, and anything you couldn't finish.
