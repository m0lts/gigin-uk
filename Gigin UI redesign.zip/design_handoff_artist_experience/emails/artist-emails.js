/* Artist-side emails. One data model renders the HTML (table layout, inline styles,
   dark-mode classes) and the plain-text version. Sample values are illustrative. */
(function () {
  const S = {
    first: 'Sam', act: 'The Fen Street Trio', email: 'sam@fenstreettrio.co.uk',
    venue: 'Jesus College Bar', booker: 'Jez', gig: 'Friday Night Live',
    day: 'Friday 13 November', short: 'Fri 13 Nov',
    where: 'Jesus College, Jesus Lane, Cambridge CB5 8BL. Come in through the Porters\u2019 Lodge and ask for the bar.',
    manage: 'https://giginmusic.com/gig/fnl-13-nov/application/7f3c\u2026',
  };
  const FOOT_APPLY = 'You\u2019re getting this because you applied to a gig on giginmusic.com.';

  const E = {
    received: {
      subject: `You\u2019ve applied to play ${S.gig} at ${S.venue}`,
      preheader: `${S.booker} has your application for ${S.day}.`,
      eyebrow: 'APPLICATION SENT',
      heading: `${S.booker} has your application`,
      paras: [`Hi ${S.first},`, `Thanks for applying. ${S.booker} at ${S.venue} has your application for <b>${S.day}</b>, and will get back to you by email.`],
      boxes: [{ label: 'YOUR APPLICATION', rows: [['Act', S.act], ['Set', `You\u2019d prefer Set 1. ${S.booker} will confirm which set you\u2019re playing.`], ['Band', '3 members']] }],
      pre: 'Need to change something, or can\u2019t make it any more? Use your private link:',
      button: ['Change or withdraw your application', S.manage],
      small: 'This link is private, so don\u2019t forward it. It works until 7 days after the gig.',
      footer: FOOT_APPLY,
    },
    accepted: {
      subject: `You\u2019re playing Set 1 at ${S.venue} on ${S.short}`,
      preheader: `Set 1, 20:00\u201321:00. Doors 19:30.`,
      eyebrow: 'YOU\u2019RE BOOKED',
      heading: 'You\u2019re playing Set 1',
      paras: [`Hi ${S.first},`, `Good news. ${S.booker} has accepted ${S.act} for ${S.gig}, and you\u2019re playing <b>Set 1, 20:00\u201321:00 on ${S.day}</b>.`],
      boxes: [{ label: 'YOUR SET', green: true, rows: [['Set', 'Set 1 \u00b7 20:00\u201321:00 (60 minutes)'], ['Doors', '19:30'], ['Where', S.where], ['Booked by', `${S.booker}, Bar Manager`]] }],
      pre: `Can\u2019t make it after all? Let ${S.booker} know from your private link, so the set can go to someone else.`,
      button: ['View your booking', S.manage],
      small: 'We\u2019ve attached a calendar file (gigin-set.ics) with your set time.',
      footer: FOOT_APPLY,
    },
    declined: {
      subject: `Update on your application for ${S.gig}`,
      preheader: `${S.booker} has picked the line-up for ${S.day}.`,
      eyebrow: 'APPLICATION UPDATE',
      heading: `Thanks for applying to ${S.gig}`,
      paras: [`Hi ${S.first},`, `${S.booker} has picked the line-up for ${S.day} and couldn\u2019t fit ${S.act} in this time. Thanks for applying. The bar has your details for future nights.`],
      button: ['See upcoming gigs at the bar', 'https://giginmusic.com/venues/jesus-college-bar'],
      buttonDark: true,
      extra: { title: 'Keep your details for next time?', body: 'Turn this application into a Gigin profile with a link you can send to other venues. You\u2019ll create a password when you confirm.', link: ['Keep my profile', 'https://giginmusic.com/profile/keep-from-email/\u2026'] },
      footer: FOOT_APPLY,
    },
    setChanged: {
      subject: `Your set has changed: you\u2019re now playing Set 2 on ${S.short}`,
      preheader: 'Set 2, 21:15\u201322:15. Everything else stays the same.',
      eyebrow: 'SET CHANGED',
      heading: 'You\u2019re now playing Set 2',
      paras: [`Hi ${S.first},`, `${S.booker} has changed the running order for ${S.gig}. ${S.act} is now playing <b>Set 2, 21:15\u201322:15 on ${S.day}</b>, instead of Set 1 at 20:00. Everything else stays the same.`],
      boxes: [{ label: 'YOUR NEW SET', green: true, rows: [['Set', 'Set 2 \u00b7 21:15\u201322:15 (60 minutes)'], ['Was', 'Set 1 \u00b7 20:00\u201321:00', true], ['Doors', '19:30']] }],
      pre: `If the new time doesn\u2019t work, let ${S.booker} know from your private link.`,
      button: ['View your booking', S.manage],
      small: 'We\u2019ve attached an updated calendar file. It replaces the earlier one.',
      footer: FOOT_APPLY,
    },
    mediaReady: {
      subject: `Your photos and videos from ${S.gig}`,
      preheader: `${S.venue} has shared 12 files from ${S.day}.`,
      eyebrow: 'PHOTOS AND VIDEOS',
      heading: `Photos from ${S.gig} are ready`,
      paras: [`Hi ${S.first},`, `${S.venue} has shared photos and videos from ${S.day} with the acts who played.`],
      boxes: [{ label: 'IN THE GALLERY', rows: [['Files', '9 photos, 3 videos'], ['Size', '184 MB in total']] }],
      button: ['View and download', 'https://giginmusic.com/share/gig-media/\u2026'],
      small: 'This link is private, so only share it with your band. The venue can turn it off at any time.',
      footer: `You\u2019re getting this because you played ${S.gig} at ${S.venue}.`,
    },
    keepConfirm: {
      subject: `Confirm your Gigin profile for ${S.act}`,
      preheader: 'Tap the link to confirm your email and create a password. Nothing is public until you do.',
      eyebrow: 'CONFIRM YOUR PROFILE',
      heading: 'Confirm your Gigin profile',
      paras: [`Hi ${S.first},`, `You asked to keep the details from your application to ${S.venue} as a Gigin profile. Tap the button to confirm your email and create a password. Nothing is public until you do.`],
      boxes: [
        { label: 'PUBLIC ON YOUR PROFILE', rows: [[S.act, 'Photo, links, band and tech rider']] },
        { label: 'PRIVATE', rows: [['Contact', 'Your email and phone number. Venues contact you through Gigin.']] },
      ],
      button: ['Confirm my profile', 'https://giginmusic.com/profile/confirm/\u2026'],
      orange: true,
      after: ['Want to change what\u2019s public first?', 'Choose what\u2019s public', 'https://giginmusic.com/profile/keep?t=\u2026'],
      small: 'This link works once and expires in 7 days. If you didn\u2019t ask for this, ignore this email and nothing will be published.',
      footer: 'You\u2019re getting this because you applied to a gig on giginmusic.com and asked to keep your details as a profile.',
    },
    passwordReset: {
      subject: 'Reset your Gigin password',
      preheader: 'The link works once, for 1 hour.',
      eyebrow: 'PASSWORD RESET',
      heading: 'Choose a new password',
      paras: [`Hi ${S.first},`, `Someone asked to reset the password for <b>${S.email}</b> on Gigin. If it was you, tap the button. The link works once, for 1 hour.`],
      button: ['Choose a new password', 'https://giginmusic.com/auth/reset?oobCode=\u2026'],
      buttonDark: true,
      small: 'If you didn\u2019t ask for this, you can ignore this email. Your password won\u2019t change.',
      footer: 'You\u2019re getting this because someone asked to reset the password for this email on giginmusic.com.',
    },
    reminder: {
      subject: `Tomorrow: you\u2019re playing Set 1 at ${S.venue}`,
      preheader: 'Set 1, 20:00\u201321:00. Doors 19:30.',
      eyebrow: 'TOMORROW',
      heading: 'You\u2019re playing tomorrow',
      paras: [`Hi ${S.first},`, `A reminder that ${S.act} is playing <b>Set 1, 20:00\u201321:00</b> at ${S.venue} on ${S.day}.`],
      boxes: [{ label: 'YOUR SET', green: true, rows: [['Set', 'Set 1 \u00b7 20:00\u201321:00 (60 minutes)'], ['Doors', '19:30'], ['Where', S.where], ['The bar has', 'PA, 2 vocal mics, DI box'], ['You\u2019re bringing', 'Your own amps'], ['Booked by', `${S.booker}, Bar Manager`]] }],
      pre: `Can\u2019t make it? Let ${S.booker} know now from your private link, so the set can go to someone else.`,
      button: ['View your booking', S.manage],
      footer: FOOT_APPLY,
    },
  };

  const FONT = "'Geist', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
  const MONO = "'Geist Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace";
  const DARK = [
    ['.bg', 'background:#0F1115 !important'],
    ['.card', 'background:#1A1D22 !important;border-color:#2A2E36 !important'],
    ['.ink', 'color:#F2F3F5 !important'],
    ['.muted', 'color:#A3A9B5 !important'],
    ['.eyebrow', 'color:#FF8A70 !important'],
    ['.box', 'background:#22262D !important;border-color:#2E333B !important'],
    ['.boxg', 'background:#1C2A22 !important;border-color:#2B4434 !important'],
    ['.labg', 'color:#7FD49A !important'],
    ['.rule', 'border-color:#2E333B !important'],
    ['.link', 'color:#FF8A70 !important'],
    ['.btnd', 'background:#F2F3F5 !important'],
    ['.btnd a', 'color:#0F1115 !important'],
  ];
  const darkCss = (prefix) => DARK.map(([s, r]) => `${prefix}${s}{${r}}`).join('\n');
  const strip = (s) => String(s).replace(/<[^>]+>/g, '');

  function html(kind, opts) {
    const e = E[kind]; if (!e) return '';
    const force = opts && opts.forceDark;
    const styles = `:root{color-scheme:light dark;supported-color-schemes:light dark;}
body{margin:0;padding:0;-webkit-text-size-adjust:100%;}
a{text-decoration:underline;}
@media (max-width:620px){.card{padding:24px 18px !important;}.btn,.btn td,.btn a{display:block !important;width:100% !important;text-align:center !important;box-sizing:border-box;}}
${force ? darkCss('') : `@media (prefers-color-scheme: dark){\n${darkCss('')}\n}\n${darkCss('[data-ogsc] ')}`}`;
    const p = (t, cls, st) => `<p class="${cls}" style="margin:0 0 14px;font-family:${FONT};${st}">${t}</p>`;
    const paras = e.paras.map((t) => p(t, 'ink', 'font-size:16px;line-height:24px;color:#0F1115;')).join('');
    const boxes = (e.boxes || []).map((b) => {
      const rows = b.rows.map(([k, v, strike], i) => `<tr><td class="muted${i ? ' rule' : ''}" valign="top" style="padding:9px 12px 9px 0;width:118px;font-family:${FONT};font-size:14px;line-height:20px;color:#6B7280;${i ? 'border-top:1px solid #E5E7EB;' : ''}">${k}</td><td class="${strike ? 'muted' : 'ink'}${i ? ' rule' : ''}" valign="top" style="padding:9px 0;font-family:${FONT};font-size:14.5px;line-height:20px;font-weight:500;color:${strike ? '#6B7280' : '#0F1115'};${strike ? 'text-decoration:line-through;' : ''}${i ? 'border-top:1px solid #E5E7EB;' : ''}">${v}</td></tr>`).join('');
      const g = b.green;
      return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="${g ? 'boxg' : 'box'}" style="margin:6px 0 18px;background:${g ? '#F3FAF5' : '#F6F7F9'};border:1px solid ${g ? '#D3EBDB' : '#F0F1F3'};border-radius:12px;"><tr><td style="padding:14px 16px 6px;"><div class="${g ? 'labg' : 'muted'}" style="font-family:${MONO};font-size:11.5px;letter-spacing:0.06em;font-weight:500;color:${g ? '#2F7A4B' : '#6B7280'};padding-bottom:4px;">${b.label}</div><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">${rows}</table></td></tr></table>`;
    }).join('');
    const pre = e.pre ? p(e.pre, 'ink', 'font-size:15px;line-height:22px;color:#0F1115;') : '';
    const bg = e.orange ? '#FF6C4B' : e.buttonDark ? '#111317' : '#FF6C4B';
    const btnCls = e.buttonDark ? 'btn btnd' : 'btn';
    const button = `<table role="presentation" cellpadding="0" cellspacing="0" border="0" class="${btnCls}" style="margin:4px 0 18px;"><tr><td class="${e.buttonDark ? 'btnd' : ''}" style="background:${bg};border-radius:10px;"><a href="${e.button[1]}" style="display:inline-block;padding:14px 22px;font-family:${FONT};font-size:15px;line-height:20px;font-weight:600;color:#FFFFFF;text-decoration:none;border-radius:10px;min-width:200px;text-align:center;">${e.button[0]}</a></td></tr></table>`;
    const after = e.after ? p(`${e.after[0]} <a class="link" href="${e.after[2]}" style="color:#B5462C;font-weight:500;">${e.after[1]}</a>`, 'ink', 'font-size:14.5px;line-height:22px;color:#0F1115;') : '';
    const extra = e.extra ? `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="box" style="margin:4px 0 18px;background:#F6F7F9;border:1px solid #F0F1F3;border-radius:12px;"><tr><td style="padding:14px 16px;font-family:${FONT};"><div class="ink" style="font-size:15px;line-height:22px;font-weight:600;color:#0F1115;">${e.extra.title}</div><div class="muted" style="font-size:14px;line-height:21px;color:#4B5160;padding:2px 0 8px;">${e.extra.body}</div><a class="link" href="${e.extra.link[1]}" style="font-size:14.5px;font-weight:600;color:#B5462C;">${e.extra.link[0]} \u2192</a></td></tr></table>` : '';
    const small = e.small ? p(e.small, 'muted', 'font-size:13.5px;line-height:20px;color:#6B7280;margin:0;') : '';
    return `<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="supported-color-schemes" content="light dark">
<title>${strip(e.subject)}</title>
<style>
${styles}
</style>
</head>
<body class="bg" style="margin:0;padding:0;background:#F6F7F9;">
<div style="display:none;max-height:0;max-width:0;overflow:hidden;opacity:0;mso-hide:all;">${e.preheader}${'&#847;&zwnj;&nbsp;'.repeat(30)}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="bg" style="background:#F6F7F9;">
<tr><td align="center" style="padding:28px 12px 32px;">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px;">
<tr><td class="card" style="background:#FFFFFF;border:1px solid #E5E7EB;border-radius:16px;padding:32px 28px;">
<div class="ink" style="font-family:${FONT};font-size:24px;line-height:28px;font-weight:700;letter-spacing:-0.01em;color:#0F1115;padding-bottom:22px;">gigin<span style="color:#FF6C4B;">.</span></div>
<div class="eyebrow" style="font-family:${MONO};font-size:12px;line-height:16px;letter-spacing:0.06em;font-weight:500;color:#B5462C;padding-bottom:8px;">${e.eyebrow}</div>
<h1 class="ink" style="margin:0 0 18px;font-family:${FONT};font-size:24px;line-height:30px;font-weight:600;letter-spacing:-0.01em;color:#0F1115;">${e.heading}</h1>
${paras}${boxes}${pre}${button}${after}${extra}${small}
</td></tr>
<tr><td class="muted" style="padding:16px 10px 0;font-family:${FONT};font-size:12.5px;line-height:19px;color:#6B7280;">${e.footer}<br>Gigin \u00b7 <a class="link" href="https://giginmusic.com" style="color:#6B7280;">giginmusic.com</a> \u00b7 <a class="link" href="https://giginmusic.com/privacy-policy" style="color:#6B7280;">Privacy</a></td></tr>
</table>
</td></tr>
</table>
</body>
</html>`;
  }

  function text(kind) {
    const e = E[kind]; if (!e) return '';
    const out = ['gigin.', '', e.eyebrow, strip(e.heading), ''];
    e.paras.forEach((t) => out.push(strip(t), ''));
    (e.boxes || []).forEach((b) => {
      out.push(b.label);
      b.rows.forEach(([k, v, strike]) => out.push(`${k}: ${strike ? `(was) ${v}` : v}`));
      out.push('');
    });
    if (e.pre) out.push(e.pre, '');
    out.push(`${e.button[0]}:`, e.button[1], '');
    if (e.after) out.push(`${e.after[0]} ${e.after[1]}:`, e.after[2], '');
    if (e.extra) out.push(e.extra.title, e.extra.body, `${e.extra.link[0]}: ${e.extra.link[1]}`, '');
    if (e.small) out.push(e.small, '');
    out.push('--', e.footer, 'Gigin \u00b7 https://giginmusic.com');
    return out.join('\n');
  }

  window.ArtistEmails = {
    kinds: Object.keys(E),
    meta: (k) => ({ subject: E[k].subject, preheader: E[k].preheader }),
    html, text,
  };
})();
